import os
import sys
from pathlib import Path

import requests
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend.generators.document_export import format_docx, format_pdf, format_txt

st.set_page_config(
    page_title="LegalEase",
    page_icon="⚖️",
    layout="wide",
)

st.title("⚖️ LegalEase")
st.caption("AI-Powered Legal Document Generator")

st.info(
    "LegalEase creates editable legal-document drafts. It is not a substitute for advice "
    "from a qualified legal professional."
)

with st.sidebar:
    st.header("Settings")
    backend_url = st.text_input(
        "FastAPI URL",
        value=os.getenv("BACKEND_URL", "http://127.0.0.1:8000"),
    )
    st.markdown("### Supported examples")
    st.write("• Employment Contract")
    st.write("• NDA")
    st.write("• Lease Agreement")
    st.write("• Service Agreement")
    st.write("• Custom Agreement")

left, right = st.columns([1, 1])

with left:
    st.subheader("Document Details")

    document_type = st.text_input(
        "Document Type",
        placeholder="e.g. Freelance Work Contract",
    )

    parties = st.text_area(
        "Parties Involved",
        placeholder="Jane Doe (Service Provider), TechNova Inc. (Client)",
        height=110,
    )

    terms = st.text_area(
        "Terms & Conditions",
        placeholder=(
            "Payment within 30 days; Confidentiality must be maintained; "
            "Either party may terminate with 15 days notice"
        ),
        height=180,
    )

    effective_date = st.text_input(
        "Effective Date",
        placeholder="October 5, 2026",
    )

    generate = st.button("✨ Generate Document", type="primary", use_container_width=True)

if "document" not in st.session_state:
    st.session_state.document = ""

if generate:
    if not all([document_type.strip(), parties.strip(), terms.strip(), effective_date.strip()]):
        st.error("Please complete all fields before generating the document.")
    else:
        payload = {
            "document_type": document_type,
            "parties": parties,
            "terms": terms,
            "effective_date": effective_date,
        }

        try:
            with st.spinner("Generating your document..."):
                response = requests.post(
                    f"{backend_url.rstrip('/')}/generate",
                    json=payload,
                    timeout=120,
                )
            response.raise_for_status()
            st.session_state.document = response.json()["document"]
            st.success("Document generated successfully.")
        except requests.RequestException as exc:
            st.error(f"Could not reach the FastAPI backend: {exc}")
        except Exception as exc:
            st.error(f"Generation failed: {exc}")

with right:
    st.subheader("Editable Preview")

    edited = st.text_area(
        "Document",
        value=st.session_state.document,
        height=480,
        label_visibility="collapsed",
        placeholder="Your generated document will appear here...",
    )
    st.session_state.document = edited

    if edited.strip():
        st.markdown("### Download")
        c1, c2, c3 = st.columns(3)

        with c1:
            st.download_button(
                "⬇️ TXT",
                data=format_txt(edited),
                file_name="legalease_document.txt",
                mime="text/plain",
                use_container_width=True,
            )

        with c2:
            st.download_button(
                "⬇️ DOCX",
                data=format_docx(edited, document_type or "Legal Document"),
                file_name="legalease_document.docx",
                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                use_container_width=True,
            )

        with c3:
            st.download_button(
                "⬇️ PDF",
                data=format_pdf(edited, document_type or "Legal Document"),
                file_name="legalease_document.pdf",
                mime="application/pdf",
                use_container_width=True,
            )
