# LegalEase — AI-Powered Legal Document Generator

LegalEase is a student-friendly full-stack project based on the supplied project specification. It uses:

- **Streamlit** — frontend
- **FastAPI** — backend API
- **Google Gemini** — AI legal-document drafting
- **python-docx** — DOCX export
- **FPDF2** — PDF export
- **TXT** — plain-text export

## Features

- Employment Contract, NDA, Lease Agreement, Service Agreement, and custom document types
- Inputs for document type, parties, terms, and effective date
- AI-generated legal document draft
- Editable generated text
- Preview
- Download as `.txt`, `.docx`, or `.pdf`
- Optional logo branding
- FastAPI `/generate` endpoint
- Health-check endpoint
- Environment-variable based API key handling

> **Important:** Generated text is a drafting aid, not legal advice. Users should have important documents reviewed by a qualified legal professional.

## Project structure

```text
LegalEase_GitHub/
├── backend/
│   ├── ai_core/
│   │   └── gemini_generator.py
│   ├── generators/
│   │   └── document_export.py
│   ├── main.py
│   ├── routes.py
│   └── schemas.py
├── frontend/
│   └── app.py
├── assets/
│   └── README.txt
├── tests/
│   └── test_api.py
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## 1. Requirements

Python 3.10+ is recommended.

## 2. Install

```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Then:

```bash
pip install -r requirements.txt
```

## 3. Configure Gemini

Copy `.env.example` to `.env`:

```text
GEMINI_API_KEY=your_api_key_here
GEMINI_MODEL=gemini-2.5-flash
```

You can change `GEMINI_MODEL` to another model available to your Gemini API account.

Never commit `.env` or your API key to GitHub.

## 4. Run the backend

From the project root:

```bash
uvicorn backend.main:app --reload
```

Backend:
`http://127.0.0.1:8000`

API documentation:
`http://127.0.0.1:8000/docs`

## 5. Run the frontend

Open another terminal in the project root:

```bash
streamlit run frontend/app.py
```

The Streamlit application will open in your browser.

## 6. API example

POST `/generate`

```json
{
  "document_type": "Non-Disclosure Agreement",
  "parties": "Jane Doe (Disclosing Party), ABC Technologies (Receiving Party)",
  "terms": "Confidential information must be protected; disclosure is limited to authorized purposes; agreement may be terminated with 15 days notice",
  "effective_date": "October 5, 2026"
}
```

## 7. GitHub

Create a new GitHub repository and run:

```bash
git init
git add .
git commit -m "Initial LegalEase project"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## Notes

The project follows the architecture in the supplied specification: Streamlit frontend → FastAPI backend → Gemini AI core → document formatting/export. The specification describes Gemini 1.5 Pro; this implementation keeps the model configurable through `GEMINI_MODEL` so it can use a currently available Gemini model without changing source code.
