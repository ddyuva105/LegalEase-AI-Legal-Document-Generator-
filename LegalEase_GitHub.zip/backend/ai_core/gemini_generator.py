import os
from dotenv import load_dotenv

try:
    from google import genai
except ImportError:
    genai = None

load_dotenv()


class GeminiDocumentGenerator:
    """Generates a structured legal-document draft using Google's Gemini API."""

    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY")
        self.model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

        if genai is None:
            raise RuntimeError("google-genai is not installed. Run: pip install -r requirements.txt")

        if not self.api_key:
            raise RuntimeError(
                "GEMINI_API_KEY is not configured. Copy .env.example to .env and add your API key."
            )

        self.client = genai.Client(api_key=self.api_key)

    def generate_document(
        self,
        document_type: str,
        parties: str,
        terms: str,
        effective_date: str,
    ) -> str:
        prompt = f"""
You are a legal-document drafting assistant.

Create a clear, professional DRAFT of the requested document.

Document type:
{document_type}

Parties:
{parties}

Effective date:
{effective_date}

Terms and conditions:
{terms}

Requirements:
- Use a professional legal-document structure.
- Include a title and logical numbered sections.
- Reflect the supplied parties, date, and terms accurately.
- Do not invent specific facts that were not supplied.
- Use placeholders such as [INSERT ...] when important information is missing.
- Keep the output editable plain text.
- Do not include markdown fences.
- State near the beginning that this is a draft and not legal advice.
"""

        response = self.client.models.generate_content(
            model=self.model,
            contents=prompt,
        )

        text = getattr(response, "text", None)
        if not text:
            raise RuntimeError("Gemini returned an empty response.")

        return text.strip()
