from fastapi import APIRouter, HTTPException

from backend.schemas import DocumentRequest
from backend.ai_core.gemini_generator import GeminiDocumentGenerator

router = APIRouter()
generator = None


def get_generator():
    global generator
    if generator is None:
        generator = GeminiDocumentGenerator()
    return generator


@router.post("/generate")
def generate_document(request: DocumentRequest):
    try:
        result = get_generator().generate_document(
            document_type=request.document_type,
            parties=request.parties,
            terms=request.terms,
            effective_date=request.effective_date,
        )
        return {"document": result}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
